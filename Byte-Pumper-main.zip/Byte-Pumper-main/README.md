# Byte-Pumper
Pump any file with null bytes 


![Capturaasdads](https://user-images.githubusercontent.com/104674473/213875946-4769d4fe-ce48-4737-87fb-25fc3f42a3a4.JPG)
